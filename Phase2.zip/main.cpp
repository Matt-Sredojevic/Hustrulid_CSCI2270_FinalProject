#include <iostream>
#include "Mailman.h"
#include <fstream>
#include <sstream>
using namespace std;

int main(int argc, const char * argv[]) {
    // declare input and instance of class
    string input = "0";
    Mailman city1;

    // run through while loop for menu
    while(input != "12"){
        cout << "======Main Menu======" << endl;
        cout << "1. Build Network" << endl;
        cout << "2. Print Network Path" << endl;
        cout << "3. Transmit Message Coast-To-Coast-To-Coast" << endl;
        cout << "4. Transmit Message To Specific City" << endl;
        cout << "5. Check Cost to Transmit Message " << endl;
        cout << "6. Add City" << endl;
        cout << "7. Delete City" << endl;
        cout << "8. Clear Network" << endl;
        cout << "9. Display Personal Balance" << endl;
        cout << "10. Print City Balance" << endl; //how much the city made from
        cout << "11. Earn More Money" << endl;
        cout << "12. Quit" << endl;


        getline(cin,input);



        // build network
        if(input == "1"){
        if(!city1.listBuilt()){
                city1.buildNetwork();
            }
            else{
                cout << "Please clear the network before re-building." << endl;
            }
        }

        // Print netowrk
        else if(input == "2"){
            if(city1.listBuilt()){
                city1.printNetwork();
            }
            else{
                std::cout << "Empty list, " << "Current Balance: " << city1.checkPersonalBalance() << std::endl;
            }
        }

        else if(input == "3"){
            if(city1.listBuilt()){
                string message;
                cout << "Please enter message to transmit accross the coast: " << endl;
                getline(cin,message);
                city1.transmitMsgCoast(message);
            }
            else{
                std::cout << "Empty list, " << "Current Balance: " << city1.checkPersonalBalance() << std::endl;
            }
        }

        else if (input == "4"){
            if(city1.listBuilt()){
                string message;
                string city;
                cout << "Please select a city to send a message to: " << endl;
                getline(cin,city);
                cout << "Please enter message to transmit: " << endl;
                getline(cin,message);
                city1.transmitMessagetoCity(city, message);
            }
            else{
                std::cout << "Empty list, " << "Current Balance: " << city1.checkPersonalBalance() << std::endl;
            }
        }


        else if (input == "5"){
            if(city1.listBuilt()){
                string city;
                cout << "Enter city to send a message to: " << endl;
                getline(cin,city);
                int cost = city1.checkCost(city);

                if(cost != 0) cout << "Cost to send message: " << city1.checkCost(city) << " dollars."<<endl;
            }
            else{
                std::cout << "Empty list, " << "Current Balance: " << city1.checkPersonalBalance() << std::endl;
            }
        }

                // add city in command window
        else if(input == "6"){
            if(city1.listBuilt()){
                string cityNew;
                string cityPrevious;
                cout << "Enter a city name: " << endl;
                getline(cin,cityNew);
                cout << "Enter a previous city name: " << endl;
                getline(cin,cityPrevious);
                city1.addCity(cityPrevious, cityNew);
            }
            else{
                cout << "Please Build Network before adding cities." << endl;
            }

        }

        // delete city
        else if(input == "7"){
            if(city1.listBuilt()){
                string cityDelete;
                cout << "Enter a city name: " << endl;
                getline(cin,cityDelete);
                //cin >> cityDelete;
                city1.deleteCity(cityDelete);
            }
            else{
                std::cout << "Empty list, " << "Current Balance: " << city1.checkPersonalBalance() << std::endl;
            }

        }

        // Clear out network
        else if(input == "8"){
            if(city1.listBuilt()){
            city1.clearNetwork();
            }
            else{
                std::cout << "Empty list, " << "Current Balance: " << city1.checkPersonalBalance() << std::endl;
            }
        }

        else if (input == "9"){
            cout << "Personal Balance: " << city1.checkPersonalBalance() <<" dollars."<< endl;
        }


        else if(input == "10"){
            if(city1.listBuilt()){
                cout << "Please enter a city name: " << endl;
                string name;
                getline(cin,name);
                city1.printCityInfo(name);
            }
            else{
                std::cout << "Empty list, " << "Current Balance: " << city1.checkPersonalBalance() <<" dollars."<< std::endl;
            }
        }

        else if (input== "11"){
            city1.chooseRandomGame();
        }

    }
    // leave program
    cout << "Goodbye!" << endl;

    return 0;
}






/*
void Mailman::earnMoney1(){
    int num, guess = 0;
    int money=10; //amount of money you will earn

	srand(time(0)); //random number generator

	num = rand() % 10 + 1; // random number between 1 and 10

	cout << "\nGuessing Game\n";
	while (guess != num){
		cout << "Enter a guess between 1 and 10 : ";
		cin >> guess;
		if (guess > num){
            cout << "Too high!\n\n";
		}
		else if (guess < num){
            cout << "Too low!\n\n";
		}
		else{
            cout << "\nCorrect! You earned " << money << " dollars!\n";
		}
	}

	cin.ignore();
	cin.get();

    personalBalance=personalBalance+10;
}

void Mailman::earnMoney2(){
    cout<<"\n RIDDLE RIDDLE!!\n"<<endl;

    int riddleAnswer1 = 0;
    int riddleAnswer2 = 0;

    bool getout=false;
    while(getout != true){
        int guesses=0;
        int tries=5;
        //first riddle
        while(riddleAnswer1 != 3 and guesses < 5 ){
            cout<<"If you have 3 hens, 2 hens, and 5 hens, how many hens?"<<endl;
            cin>>riddleAnswer1;
            if(riddleAnswer1==3){
                cout<<"Correct! There are "<<riddleAnswer1<<" of the word 'hens'." <<endl;
                cout<<"You have earned 10 dollars!"<<endl;
                personalBalance=personalBalance+10;
                getout=true;
            }
            if(tries==2){
                cout<<"Incorrect, I'll give you one more try."<<endl;
            }
            if(tries > 2 and getout != true){
                cout<<"Try again..."<<endl;
            }
            guesses++;
            tries--;
        }


        if(getout==false){
            cout<< "\n Since that riddle was too difficult, maybe you can get this one."<<endl;
            cout<<"Look for the differences in the question. \n"<<endl;
            while(riddleAnswer2 != 10){

                cout<< "If you have 3 hens, 2 hens, and 5 hens, how many hens do you have?"<<endl;
                cin>>riddleAnswer2;

                if(riddleAnswer2==10){
                    cout<<"Correct! There are "<<riddleAnswer2<<" hens." <<endl;
                    cout<<"You have earned 10 dollars!"<<endl;
                    personalBalance=personalBalance+10;
                    getout=true;
                }
                else{
                    cout<<"\n Incorrect, try again.."<<endl;
                }
            }
        }
    getout=true;
    }
}

void Mailman::earnMoney3(){
    cout<<"\n Math Wizards Get Money!!"<<endl;

    bool getout=false;
    int earnedmoney=0;

    while (getout != true){

        int answer1;
        while(answer1 != 4){
            cout<<"How many factors of 10 are there?"<<endl;
            cin>>answer1;
            if(answer1==4){
                cout<<"\n Correct! You earned 2 dollars!"<<endl;
                earnedmoney=earnedmoney+2;
            }
            else{
                cout<<"Incorrect. Try again... \n"<<endl;
            }
        }

        cout<<"Here's the next one.."<<endl;
        int answer2;
        while(answer2 != 1){
            cout<<"What is the integral from 0 to 1 of x^4"<<endl;
            cin>>answer2;
            if(answer2==1){
                cout<<"\n Correct! You earned 2 more dollars!\n"<<endl;
                earnedmoney=earnedmoney+2;

            }
            else{
                cout<<"Incorrect. Try again... \n"<<endl;
            }
        }

        int answer3;
        cout<<"For the jackpot of 10 dollars...\n"<<endl;
        cout<<"What is 10! (the factorial of 10)"<<endl;
        cin>>answer3;

        if(answer3 == 3628800){
            earnedmoney=earnedmoney+20;
            cout<<"Correct! You have earned a grand total of "<<earnedmoney<<" dollars!"<<endl;
        }
        else if(answer3 != 3628800){
            cout<<"Incorrect, yet you still earned "<<earnedmoney<< " dollars!"<<endl;
        }

        personalBalance=personalBalance+earnedmoney;
        getout=true;
    }
}

void Mailman::chooseRandomGame(){
    int randomint=rand()%4;
    if (randomint==1){
        earnMoney1();
    }
    else if(randomint==2){
        earnMoney2();
    }
    else{
        earnMoney3();
    }
}
*/
